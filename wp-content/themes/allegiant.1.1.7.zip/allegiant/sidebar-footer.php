<section id="subfooter" class="subfooter secondary-color-bg dark">
	<div class="container">
		<?php do_action( 'cpotheme_subfooter' ); ?>
	</div>
</section>
