<?php
/**
 *	The template for displaying the WooCommerce.
 *
 *	@package WordPress
 *	@subpackage riba-lite
 */
?>
<?php get_header(); ?>
<?php get_template_part( 'template-parts/content', 'woocommerce' ); ?>
<?php get_footer(); ?>