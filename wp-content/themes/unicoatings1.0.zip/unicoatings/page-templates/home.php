<?php
/**
    Template Name: Home Template
*/

get_header(); ?>
	
<!--Banner-->
<div class="banner">
    <img src="<?php the_field('home_page_image') ?>" alt="Banner" class="img-responsive">
</div>
<!--/ Banner-->
<!-- Main content -->
<section class="about">
    <div class="container">
        <div class="row">
            <div class="header-section text-center">
                <h2 class="text-uppercase"><?php the_title(); ?></h2>
                <p class="text-center">
                    <?php 
                    if(have_posts()) : 
                        while(have_posts()) : 
                            the_post();
                            the_content();
                        endwhile;
                    endif; 
                    ?>
                </p>
                <div class="divider1"></div>
            </div>
        </div>
    </div>     
</section>
<!--/ Main content -->
<!--Feature-->
<?php
$args = array('category_name' => 'services','orderby' => 'date','order' => 'ASC');
$posts = get_posts( $args );
?>
<section id="feature">
    <div class="container">
        <div class="">
            <div class="header-section text-center">
                <h2 class="text-uppercase">great reasons to choose unicoatings</h2>
            </div>
            <div class="row flex">
                <?php
                foreach( $posts as $post ): setup_postdata($post); 
                ?>
                <div class="col-md-6">
                    <div class="fea">
                        <div class="fea-img">
                            <?php echo get_the_post_thumbnail($page->ID,'full' ); ?>                       
                        </div>
                        <div class="heading">
                            <h4><?php the_title(); ?></h4>
                            <p><?php the_excerpt(); ?></p>
                        </div>
                    </div>
                </div>
                <?php
                endforeach;
                wp_reset_postdata();
                ?>
            </div> 
        </div>
    </div>
</section>
<div class="divider1"></div>
<!--/  Feature  -->


<?php get_footer(); ?>