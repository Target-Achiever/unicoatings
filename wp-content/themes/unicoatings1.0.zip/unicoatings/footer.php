        <!--Footer-->
        <footer id="footer" class="footer">
            <div class="container-fluid text-center">
                <div class="copy">
                    <div class="col-md-2">
                        <ul class="list-unstyled list-inline">
                            <li>
                                <a href="#"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/facebook.png"></a>
                            </li>
                            <li>
                                <a href="#"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/linkedin.png"></a>
                            </li>
                            <li>
                                <a href="#"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/skype.png"></a>
                            </li>
                            <li>
                                <a href="#"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/youtube.png"></a>
                            </li>
                        </ul>     
                    </div>
                    <div class="col-md-4">
                        <ul class="list-unstyled list-inline">
                            <li><span class="green"> T : </span> +31 (0)10 820 9787  </li>
                            <li><span class="green">   E :</span> info@unicoatings.com</li>
                        </ul>                  
                    </div>
                    <div class="col-md-6">
                        <p><span class="green">&copy;</span> unicoating 2018 van Weerden Poelmanweg 2, 3088 EB Rotteterdam, The Netherlands</p>                
                    </div>
                </div>
            </div>
        </footer>
        <!--/ Footer-->
        <script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/jquery.min.js"></script>
        <script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/jquery.easing.min.js"></script>
        <script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/contactform/contactform.js"></script>
        <?php wp_footer(); ?>
    </body>
</html>