<!DOCTYPE html>
<html <?php language_attributes(); ?>>

	<head>
		<title><?php wp_title('&laquo;', true, 'right'); ?><?php bloginfo('name'); ?></title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Free Bootstrap Theme by BootstrapMade.com">
        <meta name="keywords" content="free website templates, free bootstrap themes, free template, free bootstrap, free website template">
        <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open+Sans|Candal|Alegreya+Sans">
		<link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/css/font-awesome.min.css">
		<link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/css/bootstrap.min.css">
		<link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/css/imagehover.min.css">
        <link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/style.css">          
    </head>
	<body>
        <header>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-3 col-sm-12">
                        <?php
                        global $post;
                        $post_slug = $post->post_name;

                        if($post_slug == "contact-us") {
                            the_post_thumbnail();
                        }
                        else {
                            if(function_exists( 'the_custom_logo' ) ) :
                                the_custom_logo();
                            endif;
                        }
						?>
                    </div>
                    <div class="col-md-9 col-sm-12">
                        <div class="pull-right">
                            <div class="col-md-6 col-sm-6">
                                <ul class="list-unstyled list-inline">
                                    <li>
                                        <a href="#"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/facebook.png"></a>
                                    </li>
                                    <li>
                                        <a href="#"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/linkedin.png"></a>
                                    </li>
                                    <li>
                                        <a href="#"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/skype.png"></a>
                                    </li>
                                    <li>
                                        <a href="#"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/youtube.png"></a>
                                    </li>
                                </ul>                         
                            </div>
                            <div class="col-md-6 col-sm-6">
                                <ul class="list-unstyled list-inline">
                                    <li>
                                        <a href="#"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/flag1.png"></a>
                                    </li>
                                    <li>
                                        <a href="#"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/flag2.png"></a>
                                    </li>
                                    <li>
                                        <a href="#"><img src="<?php bloginfo('stylesheet_directory'); ?>/img/flag3.png"></a>
                                    </li>                             
                                </ul>
                            </div>
                            <div class="col-md-6 col-sm-6">
                                <form class="form-inline">
                                    <div class="form-group">                             
                                        <input type="text" class="form-control" placeholder="Search here...">
                                    </div>                          
                                    <button type="submit" class="btn btn-default">Go</button>
                                </form>                           
                            </div>                       
                            <div class="col-md-6 col-sm-6">
                                <button class="btn btn-primary">Login</button>
                            </div>                       
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!--Navigation bar-->
        <nav class="navbar navbar-default">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>       
                </div>      
                <div class="collapse navbar-collapse" id="myNavbar">
                    <?php
                        if ( has_nav_menu( 'primary' ) ) : 
                            wp_nav_menu( array(
                                        'theme_location' => 'primary',
                                        'items_wrap' => '<ul class="nav navbar-nav navbar-right">%3$s</ul>'
                                    ));
                        endif;
                    ?>                  
                </div>
            </div>
        </nav>
        <!--/ Navigation bar--> 

<?php wp_head(); ?>