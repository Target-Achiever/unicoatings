<?php


//  Display header menu and footer menu options in menu page
register_nav_menus( array(
		'primary' => __( 'Header Menu',  'unicoatings' )
) );

// Add active class
add_filter('nav_menu_css_class' , 'special_nav_class' , 10 , 2);

function special_nav_class ($classes, $item) {
    if (in_array('current-menu-item', $classes)){
        $classes[] = 'active ';
    }
    return $classes;
}

// Add featured image
add_theme_support( 'post-thumbnails' );

// Add style at run time
function contact_us_style() {

	global $post;
	$post_slug = $post->post_name;

	if($post_slug == "contact-us") {
		wp_enqueue_style( 'contact_style', get_stylesheet_directory_uri() . '/css/contact_style.css');
	}
}
add_action( 'wp_enqueue_scripts', 'contact_us_style' );

// To change logo
add_theme_support( 'custom-logo', array(
        'height'      => 248,
        'width'       => 248,
        'flex-height' => true,
));

//  To add widgets
add_theme_support('widgets');

// To register sidebar for 
function unicoatings_get_widgets($widget_name,$widget_id,$widget_des) {
    register_sidebar( array(
        'name'          => $widget_name,
        'id'            => $widget_id,
        'description'   => $widget_des,
        'before_widget' => '<div class="widget-area-custom">',
        'after_widget'  => '</div>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );
}

// To add multiple widgets
unicoatings_get_widgets('Left sidebar','left-sidebar-widgets','To add widgets for left sidebar');
unicoatings_get_widgets('Right sidebar','right-sidebar-widgets','To add widgets for right sidebar');
unicoatings_get_widgets('Address','contact-address','To add address');
